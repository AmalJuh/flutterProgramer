import 'package:flutter/material.dart';
import '../Drawe/Drawe.dart';


class HomeP extends StatefulWidget {
  const HomeP ({super.key});

  @override
  State<HomeP> createState() => _HomePState();
}

class _HomePState extends State<HomeP> {
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar (
        title: const Text("Home Page"),
        centerTitle: true,
        backgroundColor: Colors.blue[100],
      ),

      drawer:const Drawe(),
      body:const Center(
        child:Text("Hi in Amal's App"),
      ),
    );
  }
}

import 'package:flutter/material.dart';
class Drawe extends StatefulWidget {
  const Drawe({super.key});

  @override
  State<Drawe> createState() => _DraweState();
}

class _DraweState extends State<Drawe> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: [
          const UserAccountsDrawerHeader(
            currentAccountPicture: CircleAvatar(
              backgroundImage: AssetImage('assets/profile.png'),
            ),
            accountName: Text("Amal Aljuhani"),
            accountEmail: Text("amalmaljuhani22@gmal.com"),
            // child:
            // (backgroundColor: Colors.blue,
            // ),
          ),
          ListTile(
            title: Text("Home Page"),
            onTap: () {
              Navigator.of(context).pushNamed('/home');
            },
            splashColor: Colors.blue[100],
          ),

        ],
      ),
    );
  }
}
import 'package:flutter/material.dart';

import 'Authentication/Signin_page.dart';
import 'Authentication/Signup_page.dart';
import 'SplashScreen/SplashScreen.dart';
import 'home_page/home_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      debugShowCheckedModeBanner: false,
      home: const SplashP(),
      routes:{
        //take context from this page to home page
        '/home':(context)=> const HomeP(),
        '/Signin':(context)=> const SigninP(),
        '/Signup':(context)=> const SignupP(),

    },
    );
  }
}

import 'package:flutter/material.dart';
class SignupP extends StatefulWidget {
  const SignupP({super.key});

  @override
  State<SignupP> createState() => _SignupPState();
}

class _SignupPState extends State<SignupP> {
  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController confirmPassword = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center (

          child: Container(
            height: 450,
            width: 350,
            decoration: BoxDecoration (
              color: Colors.blue[50],
              borderRadius: BorderRadius.circular(20),
            ),
            child:Padding(
              padding:  EdgeInsets.all(15),
              child: Column(
                mainAxisAlignment:MainAxisAlignment.spaceEvenly,
                children: [
                  const Center(
                    child: Text(
                      "Sign Up",
                      style:  TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                        color: Colors.black54,
                        fontStyle: FontStyle.italic,
                      ),
                    ),

                  ),
                  TextFormField (
                    controller: email,
                    keyboardType: TextInputType.emailAddress,
                    obscureText: false,
                    decoration: InputDecoration(
                      label: const Text("Email"),
                      prefixIcon: const Icon(Icons.email),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                  TextFormField(
                    controller: password,
                    keyboardType: TextInputType.emailAddress,
                    obscureText: true,
                    decoration: InputDecoration(
                      label: Text("Password"),
                      prefixIcon: Icon(Icons.password),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),

                  TextFormField(
                    controller: confirmPassword,
                    keyboardType: TextInputType.emailAddress,
                    obscureText: true,
                    decoration: InputDecoration(
                      label: Text("confirm Password"),
                      prefixIcon: Icon(Icons.password),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),

                  ElevatedButton(
                    onPressed: () {
                      String _email = email.text.toString();
                      String _password = password.text.toString();
                      String _confirmPassword = confirmPassword.text.toString();

                      if (_email.isNotEmpty && _password.isNotEmpty && _confirmPassword.isNotEmpty) {
                        Navigator.of(context).pushNamed('/home');
                      } else {
                        print("Error");
                      }
                      print("Email is: ${email.text.toString()}");
                      print("Password is: ${password.text.toString()}");
                      print("Done sucessfully");
                    },
                    child: const Text("Login" ,
                      style:  TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        color: Colors.black54,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
    );
  }
}

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class SplashP extends StatefulWidget {
  const SplashP({super.key});

  @override
  State<SplashP> createState() => _SplashPState();
}

class _SplashPState extends State<SplashP> {
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(seconds: 2), () {
      //go to home page
      Navigator.of(context).pushNamed('/Signin');
    });
  }
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child:Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Image.asset('assets/amallogo.jpg' , height: 550,width: 550 ,),
            const CircularProgressIndicator(),
          ],
        ),
      ),
    );
  }
}
